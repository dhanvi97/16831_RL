## Running instructions for HW1

### Q1 - Behavior Cloning

I used the following bash script to run the behavior cloning on Ant and Hopper - with the default params

Ant

``` bash
python rob831/scripts/run_hw1.py \
--expert_policy_file rob831/policies/experts/Ant.pkl \
--env_name Ant-v2 --exp_name bc_ant --n_iter 1 \
--expert_data rob831/expert_data/expert_data_Ant-v2.pkl \
--video_log_freq -1
```
Hopper

``` bash
python rob831/scripts/run_hw1.py \
--expert_policy_file rob831/policies/experts/Hopper.pkl \
--env_name Hopper-v2 --exp_name bc_hopper --n_iter 1 \
--expert_data rob831/expert_data/expert_data_Hopper-v2.pkl \
--video_log_freq -1
```

### Q2 - dAgger

I used the following scripts to run dAgger on both Ant and Hopper

Ant

``` bash
python rob831/scripts/run_hw1.py \
--expert_policy_file rob831/policies/experts/Ant.pkl \
--env_name Ant-v2 --exp_name bc_ant --n_iter 10 \
--expert_data rob831/expert_data/expert_data_Ant-v2.pkl \
--do_dagger \
--video_log_freq -1
```

Hopper

```bash
python rob831/scripts/run_hw1.py \
--expert_policy_file rob831/policies/experts/Hopper.pkl \
--env_name Hopper-v2 --exp_name bc_hopper --n_iter 10 \
--expert_data rob831/expert_data/expert_data_Hopper-v2.pkl \
--do_dagger \
--video_log_freq -1
```